# enable.anc.ig#0.2.0: ENABLE ANC Interoperability IG(en)

## Pages

* [Home](index.md)
* [Background & Use Case](background.md)
* [Implementer Quickstart](quickstart.md)
* [Downloads & Templates](downloads.md)
* [EMR Mapping Guide](mapping.md)
* [The Contract](contract.md)
* [Actors](actors.md)
* [Mapping Script Recipes](mapping-scripts.md)
* [Artifacts Summary](artifacts.md)
* [Examples](examples.md)
* [Change Log](changes.md)

## Resources

### CodeSystems

* [ENABLE Ethiopia-local ANC codes](CodeSystem-enable-et-anc.md)

### Resource Profiles

* [ENABLE ANC Bundle](StructureDefinition-enable-anc-bundle.md)
* [ENABLE ANC Encounter (visit)](StructureDefinition-enable-anc-encounter.md)
* [ENABLE ANC Patient](StructureDefinition-enable-anc-patient.md)
* [ENABLE ANC Visit Number](StructureDefinition-enable-anc-visit-number.md)
* [ENABLE Expected Date of Delivery (EDD)](StructureDefinition-enable-expected-delivery-date.md)
* [ENABLE Gestational Age](StructureDefinition-enable-gestational-age.md)
* [ENABLE Last Normal Menstrual Period (LNMP) date](StructureDefinition-enable-last-menstrual-period.md)
* [ENABLE Health Facility (Organization)](StructureDefinition-enable-organization.md)

### ImplementationGuides

* [ENABLE ANC Interoperability IG](ImplementationGuide-enable.anc.ig.md)

### NamingSystems

* [EnableDhis2OrgUnitCode](NamingSystem-enable-dhis2-orgunit-code-namingsystem.md)
* [EnableClientMrn](NamingSystem-enable-mrn-namingsystem.md)

### Examples

* [ExampleAncBundleMultiVisit (Bundle)](Bundle-ExampleAncBundleMultiVisit.md)
* [ExampleAncBundleSingleVisit (Bundle)](Bundle-ExampleAncBundleSingleVisit.md)
* [EnableAncEncounterVisit1Example (Encounter)](Encounter-EnableAncEncounterVisit1Example.md)
* [EnableAncEncounterVisit2Example (Encounter)](Encounter-EnableAncEncounterVisit2Example.md)
* [EnableAncEncounterVisit3Example (Encounter)](Encounter-EnableAncEncounterVisit3Example.md)
* [EnablePlannedEncounterExample (Encounter)](Encounter-EnablePlannedEncounterExample.md)
* [EnableAncVisitNumberExample (Observation)](Observation-EnableAncVisitNumberExample.md)
* [EnableAncVisitNumberVisit2Example (Observation)](Observation-EnableAncVisitNumberVisit2Example.md)
* [EnableAncVisitNumberVisit3Example (Observation)](Observation-EnableAncVisitNumberVisit3Example.md)
* [EnableExpectedDeliveryDateExample (Observation)](Observation-EnableExpectedDeliveryDateExample.md)
* [EnableGestationalAgeExample (Observation)](Observation-EnableGestationalAgeExample.md)
* [EnableGestationalAgeVisit2Example (Observation)](Observation-EnableGestationalAgeVisit2Example.md)
* [EnableGestationalAgeVisit3Example (Observation)](Observation-EnableGestationalAgeVisit3Example.md)
* [EnableLastMenstrualPeriodExample (Observation)](Observation-EnableLastMenstrualPeriodExample.md)
* [Felege Mels Health Center (Organization)](Organization-ExampleFacility.md)
* [EnablePatientExample (Patient)](Patient-EnablePatientExample.md)
